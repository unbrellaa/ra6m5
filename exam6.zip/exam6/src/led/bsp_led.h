#ifndef __BSP_LED_H
#define __BSP_LED_H
#include "hal_data.h"
/* LED 引脚置低电平LED 灯亮*/

/* LED 初始化函数*/
void LED_Init(void);

#define Led1_On R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_02, BSP_IO_LEVEL_HIGH );
#define Led1_Off R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_02, BSP_IO_LEVEL_LOW );



void LED1_TOGGLE(void);



#endif
