#include "bsp_led.h"
/* LED 初始化函数*/
void LED_Init(void)
{

    R_IOPORT_Open (&g_ioport_ctrl, g_ioport.p_cfg);

}

void LED1_TOGGLE(void)  //读取引脚的状态
{
    bsp_io_level_t state;
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_02, &state);
    if(state==BSP_IO_LEVEL_HIGH)
    {
        Led1_Off;
    }
    else
    {
        Led1_On;
    }
}


