#include "gpt.h"

/** 定义PWM周期和系统时钟频率 */
#define SYSTEM_CLOCK_FREQ    40000000U  /* 40MHz系统时钟 */
#define PWM_FREQ             200000U    /* 200kHz PWM频率 */
#define PWM_PERIOD_COUNTS    (SYSTEM_CLOCK_FREQ / PWM_FREQ)  /* 500 counts */

/**
 * @brief 初始化GPT8定时器
 */
void Gpt8_Init(void)
{

    R_GPT_Open(&g_timer8_ctrl, &g_timer8_cfg);
    R_GPT_PeriodSet(&g_timer8_ctrl, PWM_PERIOD_COUNTS);
    R_GPT_Start(&g_timer8_ctrl);

}

/**
 * @brief 配置GPT8为互补PWM模式
 * @param duty 主输出占空比百分比 (0-100)
 */
void Gpt8_ComplementaryPwmConfig(uint8_t duty)
{
    uint32_t duty_counts;
    duty_counts = (uint32_t)duty * PWM_PERIOD_COUNTS / 100U;
    R_GPT_DutyCycleSet(&g_timer8_ctrl, duty_counts, GPT_IO_PIN_GTIOCB);
    R_GPT_DutyCycleSet(&g_timer8_ctrl,  duty_counts, GPT_IO_PIN_GTIOCA);
}

