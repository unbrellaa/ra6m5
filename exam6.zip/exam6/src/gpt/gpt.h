#ifndef GPT_GPT_H_
#define GPT_GPT_H_

#include "hal_data.h"

/* 函数声明 */
void Gpt8_Init(void);
void Gpt8_ComplementaryPwmConfig(uint8_t duty);

#endif /* GPT_GPT_H_ */
