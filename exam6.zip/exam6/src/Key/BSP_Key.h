#ifndef __BSP_Key_H
#define __BSP_Key_H

#include "hal_data.h"


void Key_Init(void);
uint32_t Key_scan(bsp_io_port_pin_t Key);
#define ADD BSP_IO_PORT_06_PIN_10
#define REDUCE BSP_IO_PORT_01_PIN_00
#define SET BSP_IO_PORT_01_PIN_01              //set键按下，下面的打开
#define MODE BSP_IO_PORT_06_PIN_01




#define SW_ON R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_02, BSP_IO_LEVEL_HIGH );
#define SW_OFF R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_02, BSP_IO_LEVEL_LOW );
#define SD_ON R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_06_PIN_02, BSP_IO_LEVEL_HIGH );
#define SD_OFF R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_06_PIN_02, BSP_IO_LEVEL_LOW );


#endif

