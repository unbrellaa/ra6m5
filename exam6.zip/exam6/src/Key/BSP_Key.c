#include "BSP_Key.h"


void Key_Init(void)
{
    R_IOPORT_Open (&g_ioport_ctrl, g_ioport.p_cfg);
}


uint32_t Key_scan(bsp_io_port_pin_t Key)      //扫描按键（按键按下是低电平）
{
    bsp_io_level_t state;
    R_IOPORT_PinRead(&g_ioport_ctrl, Key, &state);
    uint32_t a0=0;
    if(BSP_IO_LEVEL_HIGH ==state)
    {
        a0=0;

    }
    if(BSP_IO_LEVEL_LOW ==state)
    {
        a0=1;

    }
    return a0;
}


