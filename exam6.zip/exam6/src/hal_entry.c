#include "hal_data.h"
#include "OLED/OLED.h"
#include "adc/bsp_adc.h"
#include "Key/BSP_Key.h"
#include "gpt/gpt.h"
#include "timer/timer.h"

uint32_t Num;
FSP_CPP_HEADER
void R_BSP_WarmStart(bsp_warm_start_event_t event);
FSP_CPP_FOOTER


uint8_t protect_status=0;//保护状态
uint8_t pwm=0;
uint8_t pid_mode=0;
float Target_V=16.0;
float V_yuzhi=20.0;
extern volatile uint16_t adc_raw_data[2];
float volt_ch0;
float volt_ch7;
float V_xishu=1.01;
float target_raw;
float  Actual, Out;
float Error0, Error1;
float Kp=1.01f, Ki=0.0f, Kd=0.03f;
void hal_entry(void)
{
    {
        Gpt8_Init();
        Timer0_Init();
        OLED_Init();
        adc_init_custom();

        Key_Init();
        adc_start_scan();
        OLED_ShowString(1,1,"voltage:00.00V");
        OLED_ShowString(2,1,"current:00.00A");
        OLED_ShowString(3,1,"targetV:00.00V");
        OLED_ShowString(4,1,"clos");
        loop:
        while(1)
        {
            adc_start_scan();
            volt_ch0 = adc_raw_to_voltage(adc_raw_data[0]);           //P000    测电压
            volt_ch7 = adc_raw_to_voltage(adc_raw_data[1]);           //P007    测电流
            OLED_ShowNum(1, 9, volt_ch0*10, 2);
            OLED_ShowNum(1, 12, (uint16_t)(volt_ch0 *10*100)% 100, 2);
            OLED_ShowNum(2, 9, (uint16_t)volt_ch7*10, 2);
            OLED_ShowNum(2, 12, (uint16_t)(volt_ch7 *100) % 100, 2);
            OLED_ShowNum(3, 9, (uint16_t)Target_V, 2);
            OLED_ShowNum(3, 12, (uint16_t)(Target_V * 100) % 100, 2);
            OLED_ShowNum(4, 8, protect_status, 1);
            R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MICROSECONDS);
            if(Key_scan(SET) == 1)
            {
               SW_ON;
               SD_ON
               OLED_ShowString(4,1,"open");
               protect_status=1;
               pid_mode=1;
               goto loop;
            }
            if(Key_scan(MODE)==1)
            {
                SW_OFF;
                SD_OFF;
                protect_status=0;
                OLED_ShowString(4,1,"clos");
            }
            if(Key_scan(ADD)==1)
            {
                Target_V=Target_V+0.100001f;
             }
            if(Key_scan(REDUCE)==1)
            {
                Target_V=Target_V-0.099999f;
            }
            if((adc_raw_data[0]>(V_yuzhi/33*4095)))
            {
                protect_status=0;
                SW_OFF;
                SD_OFF;
            }
            adc_start_scan();
            Actual=adc_raw_data[0];
            target_raw=Target_V/33*4095;
            Error1 = Error0;
            Error0 = target_raw - Actual;
            Out=Kp * (Error0 - Error1) + Ki * Error0 + Kd * (Error0 - Error1 );
            if(Num%5==0)
            {

                        if(pid_mode==1&&protect_status==1)
                        {
                            if(adc_raw_data[0]>((Target_V+0.001)/33*4096/V_xishu))
                            {
                                pwm-=1;
                            }
                            if(Out>0)
                            {
                                pwm+=1;
                            }
                            if((adc_raw_data[0]<((Target_V+0.001)/33*4096/V_xishu))&&(adc_raw_data[0]>((Target_V-0.01)/33*4096/V_xishu)))
                            {
                                pwm=pwm;
                            }

                        }





                Gpt8_ComplementaryPwmConfig(pwm);

            }


        }




    }

#if BSP_TZ_SECURE_BUILD
    /* Enter non-secure code */
    R_BSP_NonSecureEnter();
#endif
}




/*******************************************************************************************************************//**
 * This function is called at various points during the startup process.  This implementation uses the event that is
 * called right before main() to set up the pins.
 *
 * @param[in]  event    Where at in the start up process the code is currently at
 **********************************************************************************************************************/
void R_BSP_WarmStart(bsp_warm_start_event_t event)
{
    if (BSP_WARM_START_RESET == event)
    {
#if BSP_FEATURE_FLASH_LP_VERSION != 0

        /* Enable reading from data flash. */
        R_FACI_LP->DFLCTL = 1U;

        /* Would normally have to wait tDSTOP(6us) for data flash recovery. Placing the enable here, before clock and
         * C runtime initialization, should negate the need for a delay since the initialization will typically take more than 6us. */
#endif
    }

    if (BSP_WARM_START_POST_C == event)
    {
        /* C runtime environment and system clocks are setup. */

        /* Configure pins. */
        R_IOPORT_Open (&IOPORT_CFG_CTRL, &IOPORT_CFG_NAME);

#if BSP_CFG_SDRAM_ENABLED

        /* Setup SDRAM and initialize it. Must configure pins first. */
        R_BSP_SdramInit(true);
#endif
    }
}

#if BSP_TZ_SECURE_BUILD

FSP_CPP_HEADER
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ();

/* Trustzone Secure Projects require at least one nonsecure callable function in order to build (Remove this if it is not required to build). */
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ()
{

}
FSP_CPP_FOOTER

#endif
