#include "timer.h"

extern uint32_t Num;

void Timer0_Init(void)
{
    R_AGT_Open(&g_timer0_ctrl, &g_timer0_cfg);
    R_AGT_Start(&g_timer0_ctrl);
    R_AGT_Enable(&g_timer0_ctrl);
}


void g_timer_callback(timer_callback_args_t *p_args)
{


    /* timer Callback action  */
    if (TIMER_EVENT_CYCLE_END == p_args->event)
    {
        Num++;
    }
}
