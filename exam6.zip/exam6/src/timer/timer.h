/*
 * timer.h
 *
 *  Created on: 2025年7月2日
 *      Author: 24592
 */

#ifndef TIMER_TIMER_H_
#define TIMER_TIMER_H_
#include "hal_data.h"
void Timer0_Init(void);

#endif /* TIMER_TIMER_H_ */
