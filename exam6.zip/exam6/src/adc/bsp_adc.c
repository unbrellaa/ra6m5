/*
 * adc.c
 *
 *  Created on: 2025年6月28日
 *      Author: 袁大幅
 */
#include "bsp_adc.h"
static adc_callback_args_t g_adc0_callback_memory;
volatile uint16_t adc_raw_data[2] = {0};

volatile bool adc_scan_complete = false;
void adc_callback(adc_callback_args_t *p_args)
{
    if (p_args->event == ADC_EVENT_SCAN_COMPLETE) {
            uint16_t temp[2];
            R_ADC_Read(&g_adc0_ctrl, ADC_CHANNEL_0, &temp[0]);
            R_ADC_Read(&g_adc0_ctrl, ADC_CHANNEL_7, &temp[1]);
            adc_raw_data[0] = temp[0];
            adc_raw_data[1] = temp[1];
            adc_scan_complete = true;
        }
}

void adc_init_custom(void)
{
    fsp_err_t err;
    err = R_ADC_Open(&g_adc0_ctrl,&g_adc0_cfg);
    err = R_ADC_ScanCfg(&g_adc0_ctrl,&g_adc0_channel_cfg);
    err = R_ADC_CallbackSet(&g_adc0_ctrl,adc_callback,NULL,&g_adc0_callback_memory);
    assert(FSP_SUCCESS == err);
}

// 启动ADC扫描并等待结果
void adc_start_scan(void)
{
    adc_scan_complete = false;
    R_ADC_ScanStart(&g_adc0_ctrl);
    while (!adc_scan_complete) { __NOP(); }
}
float adc_raw_to_voltage(uint16_t raw) {
    return (float)raw * 3.3 / 4095;
}
