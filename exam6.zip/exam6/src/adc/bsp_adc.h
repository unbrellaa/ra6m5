/*
 * adc.h
 *
 *  Created on: 2025年6月28日
 *      Author: 袁大幅
 */

#ifndef ADC_BSP_ADC_H_
#define ADC_BSP_ADC_H_
#include "hal_data.h"
// 新增：声明全局变量，用于存储双通道Channel 0和7的ADC原始数据
extern volatile uint16_t adc_raw_data[2];
// 新增：声明全局变量，用于标记ADC扫描是否完成
extern volatile bool adc_scan_complete;

// 声明ADC初始化函数
void adc_init_custom(void);
// 声明启动ADC扫描并等待结果的函数
void adc_start_scan(void);
// 声明将原始值转换为电压的函数
float adc_raw_to_voltage(uint16_t raw);

#endif /* ADC_BSP_ADC_H_ */
